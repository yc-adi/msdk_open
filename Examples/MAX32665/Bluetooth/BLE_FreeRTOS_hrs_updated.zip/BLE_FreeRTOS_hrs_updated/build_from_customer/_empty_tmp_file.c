// Temp file used to detect compiler defs at build time.  Safely ignore/delete
